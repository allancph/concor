#![doc(hidden)]
#![allow(clippy::all)]
#![allow(warnings)]
include!("../target/schema_generated.rs");
