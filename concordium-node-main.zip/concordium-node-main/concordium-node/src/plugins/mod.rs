//! Client plugins.

pub mod consensus;
