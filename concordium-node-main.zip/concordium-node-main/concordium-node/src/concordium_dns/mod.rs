#![deny(rust_2018_idioms)]

pub mod dns;
mod sys;
mod sys_c;
