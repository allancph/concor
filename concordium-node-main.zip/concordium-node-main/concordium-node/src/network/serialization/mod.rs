//! Network object serialization.

pub mod fbs;

#[cfg(test)]
mod tests;
