# Genesis configurations

The following genesis configurations are available in this directory.

## [genesis.json](./genesis.json)

   - slot duration 0.25s
   - average block time 10s
   - maximum block energy limit 3_000_000
