# Changelog for Concordium

## Unreleased changes
- Add support for registering data on the chain.
- Add support for adding new identity providers and anonymity revokers through
  chain updates.
